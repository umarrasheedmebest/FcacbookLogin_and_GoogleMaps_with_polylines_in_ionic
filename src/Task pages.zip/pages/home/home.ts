import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Platform, ActionSheetController } from 'ionic-angular';
import {GoogleMapsPage} from "../google-maps/google-maps";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
    constructor(
        public platform: Platform,
        public actionsheetCtrl: ActionSheetController, public navCtrl: NavController
    ) { }

    openMenu() {
        let actionSheet = this.actionsheetCtrl.create({
            title: 'Reports Types',
            cssClass: 'action-sheets-basic-page',
            buttons: [
                {
                    text: 'Block this person',
                    role: 'destructive',
                    icon: !this.platform.is('ios') ? 'trash' : null,
                    handler: () => {
                        console.log('Delete clicked');
                    }
                },
                {
                    text: 'Inform Managment',
                    icon: !this.platform.is('ios') ? 'call' : null,
                    handler: () => {
                        console.log('Share clicked');
                    }
                },
                {
                    text: 'About Pricing issue',
                    icon: !this.platform.is('ios') ? 'arrow-dropright-circle' : null,
                    handler: () => {
                        console.log('Play clicked');
                    }
                },
                {
                    text: 'Favorite',
                    icon: !this.platform.is('ios') ? 'heart-outline' : null,
                    handler: () => {
                        console.log('Favorite clicked');
                    }
                },
                {
                    text: 'Cancel',
                    role: 'cancel', // will always sort to be on the bottom
                    icon: !this.platform.is('ios') ? 'close' : null,
                    handler: () => {
                        console.log('Cancel clicked');
                    }
                }
            ]
        });
        actionSheet.present();
    }

    googleMaps(){
        this.navCtrl.push(GoogleMapsPage);
    }
}
