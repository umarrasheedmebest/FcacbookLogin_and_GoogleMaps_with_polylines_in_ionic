import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Geolocation } from '@ionic-native/geolocation';

declare var google: any;
/**
 * Generated class for the GoogleMapsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-google-maps',
  templateUrl: 'google-maps.html',
})
export class GoogleMapsPage {

    map: any;
    image: any;
    lat:any;
    long:any;

  constructor(public navCtrl: NavController, public navParams: NavParams,  private geolocation: Geolocation ) {
      const that = this;
      console.log(navParams.get('name'));
      console.log(navParams.get('image'));
      this.geolocation.getCurrentPosition().then((resp) => {
          console.log(resp.coords.latitude);
          console.log(resp.coords.longitude);
          this.lat = resp.coords.latitude;
          this.long = resp.coords.longitude;
      }).catch((error) => {
          console.log('Error getting location', error);
      });
      let watch = this.geolocation.watchPosition();
      watch.subscribe((data) => {
          console.log('lat: ' + data.coords.latitude + ', lon: ' + data.coords.longitude);
      });
      setTimeout(function(){
          that.GoogleMap(this.lat,this.long);

      },2000);

  }
    GoogleMap(lat,long){console.log("in google function");
        var latlng = new google.maps.LatLng(this.lat, this.long);
        this.map = new google.maps.Map(document.getElementById('map'), {
            center: latlng,
            zoom: 8,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        });
        this.addMarker();
    }
    addMarker(){

        let marker = new google.maps.Marker({
            map: this.map,
            animation: google.maps.Animation.DROP,
            position: this.map.getCenter()
        });

        let content = "<h4>this is your current location Bro</h4>";

        this.addInfoWindow(marker, content);

    }
    addInfoWindow(marker, content){

        let infoWindow = new google.maps.InfoWindow({
            content: content
        });

        google.maps.event.addListener(marker, 'click', () => {
            infoWindow.open(this.map, marker);
        });

    }


    ionViewDidLoad() {
    console.log('ionViewDidLoad GoogleMapsPage');
  }

}
